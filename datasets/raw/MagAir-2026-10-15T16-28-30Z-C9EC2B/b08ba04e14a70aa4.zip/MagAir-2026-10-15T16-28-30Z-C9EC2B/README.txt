MagAir schema 1. See manifest.json for setup, trial status, and coordinate conventions.
CSV streams are independent events; timestamp_s is Core Motion uptime, NOT a shared row index.
unix_s = anchorUnix + timestamp_s - anchorUptime. received_uptime_s measures callback delivery time.
Magnetometer: raw 3-axis microtesla. Accelerometer: g. Gyroscope: rad/s.
Device motion: iPad gravity, user acceleration, rotation, quaternion; xArbitraryZVertical reference.
This is iPad IMU, NOT Apple Pencil IMU. No physical pencil coordinates are directly sensed.
pencil_events.csv contains opportunistic screen touch/hover only, NOT raw Pencil IMU.
Pencil altitude is relative to the screen, azimuth to window coordinates, NOT the desk plane.
A2051 roll is unsupported: roll_rad is empty. hover_z_normalized is NOT millimeters.
Hover timestamp is callback uptime, touch timestamp is UITouch event time; see timestamp_basis.
Events outside screen/hover range are absent. Never forward-fill pose through missing periods.
Touch estimates may be corrected later: use estimation_update_index and estimated flags.
manual_static_target = user-confirmed approximate point, not instrumented ground truth.
instructed_tip_height_mm is a nominal instruction, NOT a measured height or contact sensor.
Height target 10 mm means approximately 1 cm above the desk, not screen-hover distance.
Height transitions are unlabeled; exclude them from steady surface-vs-air comparisons.
manual_height_instruction trials are separate from 2D coordinate training.
guide_only = desired motion, NEVER measured ground truth. Exclude settle/outside phases.
Edge studies: manifest trial.spec.edge/scenarioID/edgeAction identify the assigned task.
edge_train and edge_test are split by entire scenario/session; never train on edge_test.
known_edge_only = self-paced sweep on a named edge; target_x/y are empty, speed/position unknown.
manual_pose_probe = instructed fixed-tip tilt/roll, NOT measured angle; exclude from position training.
Edge blocks require both before and after edgeBaseline trials. Last baseline auto-closes the block.
Grid map scenarios: gridMapTrain / gridMapTest; grid_map_test is held out from training.
mapHold targets are 25 manual points including boundary: x=(column-1)/4, y=(row-1)/4.
manifest trial.spec.calibrationGroup pairs each row's before/after mapBaseline; do not use one session-wide baseline.
gridRow/gridColumn are 1-based; row 1 is iPad side, column 1 is user's left.
Grid path scenarios 13/14/15: gridHorizontal/gridVertical/gridDiagonal. grid_path_test is not coordinate training.
mapSweep / known_path_only = self-paced out-and-back on manifest spec.guidePathID; target_x/y stay empty.
Path ID identifies an instructed line, NOT actual position, speed, or direction at a given time.
Each path has its own before/after mapBaseline using the same calibrationGroup.
Exclude trials whose status is not completed. Repeated attempts have unique trial IDs.
Keep whole trials / repetitions together when splitting training and evaluation data.
Unknown lengths are not millimeters; aspect ratio is approximate, for display only.
Active/aborted sessions can contain partial data; retain manifest with all CSV files.