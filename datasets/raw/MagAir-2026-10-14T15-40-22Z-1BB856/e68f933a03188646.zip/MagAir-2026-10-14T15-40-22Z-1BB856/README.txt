MagAir schema 1. See manifest.json for setup, trial status, and coordinate conventions.
CSV streams are independent events; timestamp_s is Core Motion uptime, NOT a shared row index.
unix_s = anchorUnix + timestamp_s - anchorUptime. received_uptime_s measures callback delivery time.
Magnetometer: raw 3-axis microtesla. Accelerometer: g. Gyroscope: rad/s.
Device motion: iPad gravity, user acceleration, rotation, quaternion; xArbitraryZVertical reference.
This is iPad IMU, NOT Apple Pencil IMU. No physical pencil coordinates are directly sensed.
pencil_events.csv contains opportunistic screen touch/hover only, NOT raw Pencil IMU.
Pencil altitude is relative to the screen, azimuth to window coordinates, NOT the desk plane.
A2051 roll is unsupported: roll_rad is empty. hover_z_normalized is NOT millimeters.
Hover timestamp is callback uptime, touch timestamp is UITouch event time; see timestamp_basis.
Events outside screen/hover range are absent. Never forward-fill pose through missing periods.
Touch estimates may be corrected later: use estimation_update_index and estimated flags.
manual_static_target = user-confirmed approximate point, not instrumented ground truth.
guide_only = desired motion, NEVER measured ground truth. Exclude settle/outside phases.
Exclude trials whose status is not completed. Repeated attempts have unique trial IDs.
Keep whole trials / repetitions together when splitting training and evaluation data.
Unknown lengths are not millimeters; aspect ratio is approximate, for display only.
Active/aborted sessions can contain partial data; retain manifest with all CSV files.